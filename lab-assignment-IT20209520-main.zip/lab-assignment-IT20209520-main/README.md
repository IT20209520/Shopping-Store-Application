# lab-assignment-IT20209520
lab-assignment-IT20209520 created by GitHub Classroom
Simple Shopping Cart Application using Koa js and React js

I'm IT20209520(Navoda R.C)
The entire project (backend and frontend) file was too large to upload to Git. Therefor I added onthe backend folder to Git and I'm sharing One drive and Google drive links 
below with the full project

https://mysliit-my.sharepoint.com/:u:/g/personal/it20209520_my_sliit_lk/EU_aDzK4CN1CvoSQCAjKu9ABppuZtS5hCD2J-Fj0bNmttQ?e=A0PLhM

https://drive.google.com/drive/folders/1AttnFueTmTSjvx9qCC4ttCzKSuscCvNb?usp=sharing
